from django.apps import AppConfig


class NumconversionConfig(AppConfig):
    name = 'numconversion'
